package com.student.controller;

import com.student.entity.StudentEntity;
import com.student.service.StudentService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * REST Controller: Student query API.
 *
 * Endpoints:
 *  GET /api/students/top            — top students (grade >= 85)
 *  GET /api/students/failed         — failed students (grade < 50)
 *  GET /api/students/department/{d} — students by department
 */
@Slf4j
@RestController
@RequestMapping("/api/students")
@RequiredArgsConstructor
public class StudentController {

    private final StudentService studentService;

    @GetMapping("/top")
    public ResponseEntity<List<StudentEntity>> getTopStudents() {
        return ResponseEntity.ok(studentService.getTopStudents());
    }

    @GetMapping("/failed")
    public ResponseEntity<List<StudentEntity>> getFailedStudents() {
        return ResponseEntity.ok(studentService.getFailedStudents());
    }

    @GetMapping("/department/{dept}")
    public ResponseEntity<List<StudentEntity>> getByDepartment(@PathVariable String dept) {
        return ResponseEntity.ok(studentService.getByDepartment(dept));
    }
}
