package com.student.controller;

import com.student.batch.monitor.BatchMonitoringService;
import com.student.dto.BatchJobStatusDTO;
import com.student.dto.StudentStatsDTO;
import com.student.entity.BatchJobExecutionEntity;
import com.student.service.BatchOrchestrationService;
import com.student.service.StudentService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

/**
 * REST Controller: Batch Monitoring API
 *
 * Endpoints:
 *  GET  /api/batch/jobs              — list all job executions
 *  GET  /api/batch/jobs/{status}     — filter by status
 *  GET  /api/batch/stats             — student statistics from DB
 *  POST /api/batch/run               — trigger jobs manually
 *
 * WHY REST for batch monitoring:
 *  Enterprise batch systems need operational visibility without
 *  accessing the server directly. This API serves dashboards/alerts.
 */
@Slf4j
@RestController
@RequestMapping("/api/batch")
@RequiredArgsConstructor
public class BatchMonitoringController {

    private final BatchMonitoringService     monitoringService;
    private final StudentService             studentService;
    private final BatchOrchestrationService  orchestrationService;

    /**
     * GET /api/batch/jobs
     * Returns all job execution records ordered by start time DESC.
     */
    @GetMapping("/jobs")
    public ResponseEntity<List<BatchJobStatusDTO>> getAllJobs() {
        List<BatchJobStatusDTO> jobs = monitoringService.getAllExecutions()
                .stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
        return ResponseEntity.ok(jobs);
    }

    /**
     * GET /api/batch/jobs/status/{status}
     * Filter by status: RUNNING | COMPLETED | FAILED
     */
    @GetMapping("/jobs/status/{status}")
    public ResponseEntity<List<BatchJobStatusDTO>> getByStatus(@PathVariable String status) {
        List<BatchJobStatusDTO> jobs = monitoringService.getByStatus(status.toUpperCase())
                .stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
        return ResponseEntity.ok(jobs);
    }

    /**
     * GET /api/batch/stats
     * Returns aggregated student statistics from the database.
     */
    @GetMapping("/stats")
    public ResponseEntity<StudentStatsDTO> getStats() {
        return ResponseEntity.ok(studentService.buildStats());
    }

    /**
     * POST /api/batch/run
     * Manually triggers a re-run of all batch jobs.
     * Useful for operational re-processing.
     */
    @PostMapping("/run")
    public ResponseEntity<String> triggerRun() {
        log.info("Manual batch run triggered via REST API");
        new Thread(() -> {
            try {
                orchestrationService.runAllJobs();
            } catch (Exception e) {
                log.error("Manual run error: {}", e.getMessage(), e);
            }
        }, "manual-batch-trigger").start();
        return ResponseEntity.accepted().body("Batch jobs triggered. Check /api/batch/jobs for status.");
    }

    /**
     * GET /api/batch/health
     * Quick health check for monitoring systems.
     */
    @GetMapping("/health")
    public ResponseEntity<Object> health() {
        long total = studentService.buildStats().getTotalStudents();
        return ResponseEntity.ok(java.util.Map.of(
                "status", "UP",
                "studentsInDb", total,
                "timestamp", java.time.LocalDateTime.now().toString()
        ));
    }

    private BatchJobStatusDTO toDTO(BatchJobExecutionEntity e) {
        return BatchJobStatusDTO.builder()
                .id(e.getId())
                .jobName(e.getJobName())
                .status(e.getStatus())
                .startTime(e.getStartTime())
                .endTime(e.getEndTime())
                .recordsRead(e.getRecordsRead())
                .recordsWritten(e.getRecordsWritten())
                .recordsSkipped(e.getRecordsSkipped())
                .durationMs(e.getDurationMs())
                .errorMessage(e.getErrorMessage())
                .build();
    }
}
