package com.student.generator;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.student.dto.StudentDTO;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * DataGenerator: Creates input CSV and JSON files for batch processing.
 *
 * Generates realistic student data with:
 *  - Random grades (30–100)
 *  - Multiple departments and subjects
 *  - A small percentage of intentionally invalid records (tests skip logic)
 *
 * Design: Component bean (managed by Spring), uses Builder pattern for DTOs.
 */
@Slf4j
@Component
public class DataGenerator {

    private static final String[] DEPARTMENTS  = {"CS", "IT", "IS", "AI", "SE"};
    private static final String[] SUBJECTS     = {
        "Math", "Physics", "Programming", "DataStructures",
        "Algorithms", "Database", "Networks", "AI", "OOP", "OS"
    };
    private static final String[] SEMESTERS    = {"Fall2023", "Spring2024", "Fall2024"};
    private static final String[] FIRST_NAMES  = {
        "Ahmed", "Mohamed", "Sara", "Nour", "Omar",
        "Aya", "Ali", "Hana", "Youssef", "Mariam",
        "Khaled", "Dina", "Tarek", "Rana", "Samy"
    };
    private static final String[] LAST_NAMES   = {
        "Hassan", "Ali", "Mohamed", "Ahmed", "Ibrahim",
        "Mahmoud", "Mostafa", "Kamal", "Salem", "Nasser"
    };

    @Value("${app.data.input-dir:data/input}")
    private String inputDir;

    @Value("${app.data.total-students:100000}")
    private int totalStudents;

    private final ObjectMapper objectMapper = new ObjectMapper();

    /**
     * Generates both CSV and JSON input files.
     */
    public void generateAll() throws IOException {
        File dir = new File(inputDir);
        dir.mkdirs();
        log.info("Generating input data: {} students", totalStudents);

        generateCsv(totalStudents);

        // JSON file uses a different ID range to avoid duplicate key conflicts
        generateJson(totalStudents / 10);

        log.info("Input data generation complete.");
    }

    // ─── CSV Generation ───────────────────────────────────

    public void generateCsv(int rows) throws IOException {
        String path = inputDir + "/students.csv";
        log.info("Generating CSV: {} rows → {}", rows, path);
        long start = System.currentTimeMillis();

        Random rand = new Random(42);

        try (FileWriter fw = new FileWriter(path);
             CSVPrinter printer = new CSVPrinter(fw,
                     CSVFormat.DEFAULT.builder()
                             .setHeader("studentId","name","department","subject","grade","semester")
                             .build())) {

            for (int i = 1; i <= rows; i++) {
                // Inject ~1% intentionally bad records to test skip logic
                if (i % 100 == 0) {
                    printer.printRecord(i, "", "INVALID_DEPT", "Math", 999.9, "Bad2024");
                    continue;
                }
                printer.printRecord(
                        i,
                        randomName(rand),
                        DEPARTMENTS[rand.nextInt(DEPARTMENTS.length)],
                        SUBJECTS[rand.nextInt(SUBJECTS.length)],
                        Math.round((30 + rand.nextDouble() * 70) * 10.0) / 10.0,
                        SEMESTERS[rand.nextInt(SEMESTERS.length)]
                );
            }
        }

        log.info("CSV generated in {}ms: {}", System.currentTimeMillis() - start, path);
    }

    // ─── JSON Generation ──────────────────────────────────

    public void generateJson(int count) throws IOException {
        String path = inputDir + "/students.json";
        log.info("Generating JSON: {} records → {}", count, path);
        long start = System.currentTimeMillis();

        Random rand = new Random(99);
        int idOffset = 1_000_000; // distinct IDs from CSV range

        List<StudentDTO> students = new ArrayList<>(count);
        for (int i = 1; i <= count; i++) {
            students.add(StudentDTO.builder()
                    .studentId(idOffset + i)
                    .name(randomName(rand))
                    .department(DEPARTMENTS[rand.nextInt(DEPARTMENTS.length)])
                    .subject(SUBJECTS[rand.nextInt(SUBJECTS.length)])
                    .grade(Math.round((30 + rand.nextDouble() * 70) * 10.0) / 10.0)
                    .semester(SEMESTERS[rand.nextInt(SEMESTERS.length)])
                    .build());
        }

        objectMapper.writerWithDefaultPrettyPrinter()
                .writeValue(new File(path), students);

        log.info("JSON generated in {}ms: {}", System.currentTimeMillis() - start, path);
    }

    private String randomName(Random rand) {
        return FIRST_NAMES[rand.nextInt(FIRST_NAMES.length)]
                + " " + LAST_NAMES[rand.nextInt(LAST_NAMES.length)];
    }
}
