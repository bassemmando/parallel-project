package com.student.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;

import java.time.LocalDateTime;

/**
 * JPA Entity representing a Student record in the database.
 *
 * Design: Entity layer is isolated from DTO and domain model layers
 * following Clean Architecture principles.
 */
@Entity
@Table(name = "students", indexes = {
    @Index(name = "idx_department", columnList = "department"),
    @Index(name = "idx_grade",      columnList = "grade"),
    @Index(name = "idx_semester",   columnList = "semester")
})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
public class StudentEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "student_id", unique = true, nullable = false)
    @NotNull
    private Integer studentId;

    @Column(name = "name", nullable = false, length = 100)
    @NotBlank
    @Size(max = 100)
    private String name;

    @Column(name = "department", nullable = false, length = 10)
    @NotBlank
    private String department;

    @Column(name = "subject", nullable = false, length = 50)
    @NotBlank
    private String subject;

    @Column(name = "grade", nullable = false)
    @DecimalMin("0.0")
    @DecimalMax("100.0")
    private Double grade;

    @Column(name = "semester", length = 20)
    private String semester;

    @Column(name = "status", length = 10)
    private String status;        // PASSED / FAILED / TOP

    @Column(name = "grade_category", length = 15)
    private String gradeCategory; // EXCELLENT / GOOD / AVERAGE / BELOW_AVERAGE / FAIL

    @Column(name = "processed_at")
    private LocalDateTime processedAt;

    @Column(name = "source_file", length = 50)
    private String sourceFile;    // csv / json / db

    /**
     * Business logic: determine if student passed
     */
    public boolean isPassed() {
        return grade != null && grade >= 50.0;
    }

    /**
     * Business logic: determine if student is top-performer
     */
    public boolean isTopStudent() {
        return grade != null && grade >= 85.0;
    }
}
