package com.student.util;

import com.student.dto.StudentStatsDTO;
import com.student.service.BatchOrchestrationService.BatchSummary;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * ReportPrinter: Console report generation utility.
 * Separated from service layer following Single Responsibility Principle.
 */
@Slf4j
@Component
public class ReportPrinter {

    public void printFinalReport(StudentStatsDTO stats,
                                  BatchSummary csv,
                                  BatchSummary json,
                                  BatchSummary report,
                                  long totalMs) {
        System.out.println();
        System.out.println("╔══════════════════════════════════════════════════════════════╗");
        System.out.println("║         STUDENT BATCH PROCESSOR — FINAL REPORT              ║");
        System.out.println("╠══════════════════════════════════════════════════════════════╣");
        System.out.printf( "║  Total Students   : %,10d                               ║%n", stats.getTotalStudents());
        System.out.printf( "║  Passed           : %,10d  (%.1f%%)                    ║%n", stats.getPassedStudents(), stats.getPassRate());
        System.out.printf( "║  Failed           : %,10d  (%.1f%%)                    ║%n", stats.getFailedStudents(), stats.getFailRate());
        System.out.printf( "║  Top Students(≥85): %,10d                               ║%n", stats.getTopStudents());
        System.out.printf( "║  Average Grade    :     %6.2f                               ║%n", stats.getAverageGrade());
        System.out.printf( "║  Highest Grade    :     %6.1f                               ║%n", stats.getHighestGrade());
        System.out.printf( "║  Lowest Grade     :     %6.1f                               ║%n", stats.getLowestGrade());
        System.out.println("╠══════════════════════════════════════════════════════════════╣");
        System.out.println("║                    BATCH JOB SUMMARY                        ║");
        System.out.println("╠══════════════════════════════════════════════════════════════╣");
        printJobRow(csv);
        printJobRow(json);
        printJobRow(report);
        System.out.printf("║  ─── TOTAL PIPELINE TIME: %.2f sec ──────────────────────── ║%n",
                totalMs / 1000.0);
        System.out.println("╠══════════════════════════════════════════════════════════════╣");
        System.out.println("║                  DEPARTMENT BREAKDOWN                       ║");
        System.out.println("╠══════════════════════════════════════════════════════════════╣");

        if (stats.getDepartmentStats() != null) {
            stats.getDepartmentStats().forEach((dept, d) ->
                System.out.printf("║  %-4s  Total:%,6d  Avg:%5.1f  Pass:%5.1f%%                    ║%n",
                        dept, d.getTotal(), d.getAvgGrade(), d.getPassRate())
            );
        }

        System.out.println("╠══════════════════════════════════════════════════════════════╣");
        System.out.println("║              GRADE CATEGORY DISTRIBUTION                    ║");
        System.out.println("╠══════════════════════════════════════════════════════════════╣");

        if (stats.getGradeCategoryDistribution() != null) {
            stats.getGradeCategoryDistribution().forEach((cat, count) ->
                System.out.printf("║  %-15s : %,10d                                  ║%n", cat, count)
            );
        }

        System.out.println("╠══════════════════════════════════════════════════════════════╣");
        System.out.println("║  📁 Outputs:                                                 ║");
        System.out.println("║     data/input/students.csv      — generated input           ║");
        System.out.println("║     data/input/students.json     — generated JSON input      ║");
        System.out.println("║     data/output/all_students_report.csv  — full report       ║");
        System.out.println("║     logs/student-batch.log       — application log           ║");
        System.out.println("║     http://localhost:8080/api/batch/jobs — REST monitor      ║");
        System.out.println("╚══════════════════════════════════════════════════════════════╝");

        log.info("Final report printed. Application stays running for REST API access.");
    }

    private void printJobRow(BatchSummary s) {
        System.out.printf("║  %-25s  status=%-9s  read=%,7d  written=%,7d  ║%n",
                s.jobName(), s.status(), s.recordsRead(), s.recordsWritten());
    }
}
