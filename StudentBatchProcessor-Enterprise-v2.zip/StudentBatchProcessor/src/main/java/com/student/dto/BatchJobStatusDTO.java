package com.student.dto;

import lombok.*;
import java.time.LocalDateTime;

/**
 * DTO for batch job execution status responses via REST API.
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BatchJobStatusDTO {
    private Long id;
    private String jobName;
    private String status;
    private LocalDateTime startTime;
    private LocalDateTime endTime;
    private Long recordsRead;
    private Long recordsWritten;
    private Long recordsSkipped;
    private Long durationMs;
    private String errorMessage;
}
