package com.student.dto;

import lombok.*;

import java.util.Map;

/**
 * DTO carrying aggregated statistics for reporting layer.
 * Built using the Builder pattern.
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
public class StudentStatsDTO {

    private long totalStudents;
    private long passedStudents;
    private long failedStudents;
    private long topStudents;
    private double averageGrade;
    private double highestGrade;
    private double lowestGrade;
    private double passRate;
    private double failRate;
    private Map<String, DepartmentStatsDTO> departmentStats;
    private Map<String, Long> gradeCategoryDistribution;

    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class DepartmentStatsDTO {
        private String department;
        private long total;
        private long passed;
        private long failed;
        private double avgGrade;
        private double minGrade;
        private double maxGrade;
        private double passRate;
    }
}
