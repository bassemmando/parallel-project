package com.student.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.*;
import lombok.*;

/**
 * DTO used for reading raw student data from CSV/JSON sources.
 * Kept separate from Entity to respect Clean Architecture boundaries.
 *
 * Design Pattern: Builder Pattern via Lombok @Builder
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
public class StudentDTO {

    @JsonProperty("StudentID")
    @NotNull(message = "StudentID cannot be null")
    private Integer studentId;

    @JsonProperty("Name")
    @NotBlank(message = "Name cannot be blank")
    @Size(max = 100, message = "Name cannot exceed 100 characters")
    private String name;

    @JsonProperty("Department")
    @NotBlank(message = "Department cannot be blank")
    private String department;

    @JsonProperty("Subject")
    @NotBlank(message = "Subject cannot be blank")
    private String subject;

    @JsonProperty("Grade")
    @NotNull(message = "Grade cannot be null")
    @DecimalMin(value = "0.0", message = "Grade must be >= 0")
    @DecimalMax(value = "100.0", message = "Grade must be <= 100")
    private Double grade;

    @JsonProperty("Semester")
    private String semester;
}
