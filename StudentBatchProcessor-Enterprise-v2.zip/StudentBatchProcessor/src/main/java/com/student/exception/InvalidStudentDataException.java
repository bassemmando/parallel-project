package com.student.exception;

/**
 * Thrown when a StudentDTO fails validation in the ItemProcessor.
 * Marked as "skippable" in batch job configuration — bad records
 * are logged and skipped rather than stopping the entire job.
 */
public class InvalidStudentDataException extends RuntimeException {

    public InvalidStudentDataException(String message) {
        super(message);
    }

    public InvalidStudentDataException(String message, Throwable cause) {
        super(message, cause);
    }
}
