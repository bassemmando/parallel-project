package com.student.exception;

public class BatchDataReadException extends RuntimeException {
    public BatchDataReadException(String message) { super(message); }
    public BatchDataReadException(String message, Throwable cause) { super(message, cause); }
}
