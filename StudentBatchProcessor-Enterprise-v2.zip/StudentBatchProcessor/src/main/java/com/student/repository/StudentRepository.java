package com.student.repository;

import com.student.entity.StudentEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

/**
 * Repository layer — only data access concerns here.
 * Follows Repository Pattern from DDD.
 */
@Repository
public interface StudentRepository extends JpaRepository<StudentEntity, Long> {

    List<StudentEntity> findByDepartment(String department);

    List<StudentEntity> findByGradeGreaterThanEqualOrderByGradeDesc(Double grade);

    List<StudentEntity> findByGradeLessThanOrderByGradeAsc(Double grade);

    List<StudentEntity> findBySemester(String semester);

    long countByStatus(String status);

    @Query("SELECT s.department, COUNT(s), AVG(s.grade), MIN(s.grade), MAX(s.grade) " +
           "FROM StudentEntity s GROUP BY s.department ORDER BY s.department")
    List<Object[]> getDepartmentStatistics();

    @Query("SELECT COUNT(s) FROM StudentEntity s WHERE s.grade >= 50")
    long countPassed();

    @Query("SELECT COUNT(s) FROM StudentEntity s WHERE s.grade < 50")
    long countFailed();

    @Query("SELECT AVG(s.grade) FROM StudentEntity s")
    Double getAverageGrade();

    @Query("SELECT MAX(s.grade) FROM StudentEntity s")
    Double getHighestGrade();

    @Query("SELECT MIN(s.grade) FROM StudentEntity s")
    Double getLowestGrade();

    @Query("SELECT s.gradeCategory, COUNT(s) FROM StudentEntity s GROUP BY s.gradeCategory")
    List<Object[]> getGradeCategoryDistribution();

    boolean existsByStudentId(Integer studentId);
}
