package com.student.repository;

import com.student.entity.BatchJobExecutionEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface BatchJobExecutionRepository extends JpaRepository<BatchJobExecutionEntity, Long> {
    List<BatchJobExecutionEntity> findAllByOrderByStartTimeDesc();
    Optional<BatchJobExecutionEntity> findTopByJobNameOrderByStartTimeDesc(String jobName);
    List<BatchJobExecutionEntity> findByStatus(String status);
}
