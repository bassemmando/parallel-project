package com.student;

import com.student.generator.DataGenerator;
import com.student.service.BatchOrchestrationService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

/**
 * ╔══════════════════════════════════════════════════════════════╗
 * ║     Student Batch Processor - Enterprise Edition v2.0        ║
 * ║     Spring Batch + Clean Architecture + Design Patterns      ║
 * ╚══════════════════════════════════════════════════════════════╝
 */
@Slf4j
@SpringBootApplication
public class StudentBatchApplication {

    private final DataGenerator dataGenerator;
    private final BatchOrchestrationService orchestrationService;

    public StudentBatchApplication(DataGenerator dataGenerator,
                                   BatchOrchestrationService orchestrationService) {
        this.dataGenerator       = dataGenerator;
        this.orchestrationService = orchestrationService;
    }

    public static void main(String[] args) {
        SpringApplication.run(StudentBatchApplication.class, args);
    }

    @Bean
    public CommandLineRunner run() {
        return args -> {
            printBanner();
            log.info("Starting Student Batch Processing System...");
            dataGenerator.generateAll();
            orchestrationService.runAllJobs();
            log.info("All batch jobs completed. REST API available at http://localhost:8080");
        };
    }

    private void printBanner() {
        System.out.println("""
                ╔══════════════════════════════════════════════════════════════╗
                ║   🎓 Student Batch Processor — Enterprise Edition v2.0       ║
                ║   Spring Batch + Clean Architecture + Design Patterns        ║
                ║   ETL: CSV → JSON → Database → Reports                       ║
                ╚══════════════════════════════════════════════════════════════╝
                """);
    }
}
