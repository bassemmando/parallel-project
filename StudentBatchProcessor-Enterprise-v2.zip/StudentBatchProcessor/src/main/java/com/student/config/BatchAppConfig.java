package com.student.config;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.task.TaskExecutor;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

/**
 * Application-level configuration.
 *
 * Provides:
 *  - TaskExecutor bean for multi-threaded batch steps
 *  - (Singleton Pattern: Spring manages beans as singletons by default)
 */
@Slf4j
@Configuration
public class BatchAppConfig {

    @Value("${app.batch.thread-pool-size:4}")
    private int threadPoolSize;

    /**
     * TaskExecutor for multi-threaded step processing.
     *
     * Preserves the original project's multi-threading approach,
     * now wired into Spring Batch's step builder.
     *
     * WHY ThreadPoolTaskExecutor:
     *  - Fixed thread pool prevents unbounded thread creation
     *  - Named threads aid debugging ("batch-thread-N")
     *  - CallerRunsPolicy prevents task rejection under load
     */
    @Bean("batchTaskExecutor")
    public TaskExecutor batchTaskExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(threadPoolSize);
        executor.setMaxPoolSize(threadPoolSize * 2);
        executor.setQueueCapacity(50);
        executor.setThreadNamePrefix("batch-thread-");
        executor.setWaitForTasksToCompleteOnShutdown(true);
        executor.setAwaitTerminationSeconds(300);
        executor.initialize();
        log.info("BatchTaskExecutor initialized: coreSize={}, maxSize={}",
                threadPoolSize, threadPoolSize * 2);
        return executor;
    }
}
