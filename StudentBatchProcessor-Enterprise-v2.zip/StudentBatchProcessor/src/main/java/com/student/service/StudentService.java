package com.student.service;

import com.student.dto.StudentStatsDTO;
import com.student.entity.StudentEntity;
import com.student.repository.StudentRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Service layer: business logic for student statistics and queries.
 * Follows Single Responsibility Principle — only aggregation/reporting logic.
 *
 * Template Method Pattern: buildStats() defines the skeleton of the stats
 * building algorithm; sub-methods fill in specific parts.
 */
@Slf4j
@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class StudentService {

    private final StudentRepository studentRepository;

    /**
     * Template Method Pattern: builds complete statistics in a defined sequence.
     */
    public StudentStatsDTO buildStats() {
        log.info("Building student statistics from database...");

        long total   = studentRepository.count();
        long passed  = studentRepository.countPassed();
        long failed  = studentRepository.countFailed();
        long top     = studentRepository.countByStatus("TOP");
        Double avg   = studentRepository.getAverageGrade();
        Double max   = studentRepository.getHighestGrade();
        Double min   = studentRepository.getLowestGrade();

        Map<String, StudentStatsDTO.DepartmentStatsDTO> deptMap = buildDepartmentStats();
        Map<String, Long> categoryDist = buildCategoryDistribution();

        StudentStatsDTO stats = StudentStatsDTO.builder()
                .totalStudents(total)
                .passedStudents(passed)
                .failedStudents(failed)
                .topStudents(top)
                .averageGrade(avg != null ? avg : 0.0)
                .highestGrade(max != null ? max : 0.0)
                .lowestGrade(min != null ? min : 0.0)
                .passRate(total > 0 ? (passed * 100.0 / total) : 0.0)
                .failRate(total > 0 ? (failed * 100.0 / total) : 0.0)
                .departmentStats(deptMap)
                .gradeCategoryDistribution(categoryDist)
                .build();

        log.info("Stats built: total={}, passed={}, failed={}, avg={}",
                total, passed, failed, String.format("%.2f", stats.getAverageGrade()));
        return stats;
    }

    public List<StudentEntity> getTopStudents() {
        return studentRepository.findByGradeGreaterThanEqualOrderByGradeDesc(85.0);
    }

    public List<StudentEntity> getFailedStudents() {
        return studentRepository.findByGradeLessThanOrderByGradeAsc(50.0);
    }

    public List<StudentEntity> getByDepartment(String dept) {
        return studentRepository.findByDepartment(dept.toUpperCase());
    }

    // ─── Private helpers ──────────────────────────────────

    private Map<String, StudentStatsDTO.DepartmentStatsDTO> buildDepartmentStats() {
        List<Object[]> rows = studentRepository.getDepartmentStatistics();
        Map<String, StudentStatsDTO.DepartmentStatsDTO> map = new LinkedHashMap<>();
        for (Object[] row : rows) {
            String dept  = (String) row[0];
            long total   = ((Number) row[1]).longValue();
            double avg   = ((Number) row[2]).doubleValue();
            double min   = ((Number) row[3]).doubleValue();
            double max   = ((Number) row[4]).doubleValue();
            long passed  = studentRepository.findByDepartment(dept).stream()
                           .filter(StudentEntity::isPassed).count();
            long failed  = total - passed;
            double pRate = total > 0 ? (passed * 100.0 / total) : 0.0;
            map.put(dept, StudentStatsDTO.DepartmentStatsDTO.builder()
                    .department(dept).total(total).passed(passed)
                    .failed(failed).avgGrade(avg).minGrade(min)
                    .maxGrade(max).passRate(pRate).build());
        }
        return map;
    }

    private Map<String, Long> buildCategoryDistribution() {
        List<Object[]> rows = studentRepository.getGradeCategoryDistribution();
        Map<String, Long> map = new LinkedHashMap<>();
        for (Object[] row : rows) {
            map.put((String) row[0], ((Number) row[1]).longValue());
        }
        return map;
    }
}
