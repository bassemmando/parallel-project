package com.student.service;

import com.student.dto.StudentStatsDTO;
import com.student.util.ReportPrinter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.*;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

/**
 * Orchestration Service: coordinates the execution of all batch jobs.
 *
 * Job Execution Order:
 *   1. csvStudentJob    — Extract CSV → Transform → Load DB
 *   2. jsonStudentJob   — Extract JSON → Transform → Load DB
 *   3. reportGenerationJob — DB → CSV report files
 *   4. Print console summary
 */
@Slf4j
@Service
public class BatchOrchestrationService {

    private final JobLauncher    jobLauncher;
    private final Job            csvStudentJob;
    private final Job            jsonStudentJob;
    private final Job            reportGenerationJob;
    private final StudentService studentService;
    private final ReportPrinter  reportPrinter;

    public BatchOrchestrationService(
            JobLauncher jobLauncher,
            @Qualifier("csvStudentJob")        Job csvStudentJob,
            @Qualifier("jsonStudentJob")       Job jsonStudentJob,
            @Qualifier("reportGenerationJob")  Job reportGenerationJob,
            StudentService studentService,
            ReportPrinter reportPrinter) {
        this.jobLauncher         = jobLauncher;
        this.csvStudentJob       = csvStudentJob;
        this.jsonStudentJob      = jsonStudentJob;
        this.reportGenerationJob = reportGenerationJob;
        this.studentService      = studentService;
        this.reportPrinter       = reportPrinter;
    }

    public void runAllJobs() {
        log.info("╔══════════════════════════════════════════╗");
        log.info("║   Starting Batch Job Orchestration        ║");
        log.info("╚══════════════════════════════════════════╝");

        long totalStart = System.currentTimeMillis();

        BatchSummary csvResult    = launchJob(csvStudentJob,        "csvStudentJob");
        BatchSummary jsonResult   = launchJob(jsonStudentJob,       "jsonStudentJob");
        BatchSummary reportResult = launchJob(reportGenerationJob,  "reportGenerationJob");

        long totalMs = System.currentTimeMillis() - totalStart;

        StudentStatsDTO stats = studentService.buildStats();
        reportPrinter.printFinalReport(stats, csvResult, jsonResult, reportResult, totalMs);
    }

    public BatchSummary launchJob(Job job, String jobName) {
        log.info("Launching job: {}", jobName);
        long start = System.currentTimeMillis();

        JobParameters params = new JobParametersBuilder()
                .addString("jobName",   jobName)
                .addString("timestamp", LocalDateTime.now().toString())
                .toJobParameters();

        try {
            JobExecution execution = jobLauncher.run(job, params);
            long duration = System.currentTimeMillis() - start;

            long read    = execution.getStepExecutions().stream().mapToLong(StepExecution::getReadCount).sum();
            long written = execution.getStepExecutions().stream().mapToLong(StepExecution::getWriteCount).sum();
            long skipped = execution.getStepExecutions().stream()
                    .mapToLong(s -> s.getReadSkipCount() + s.getProcessSkipCount() + s.getWriteSkipCount()).sum();

            log.info("Job {} finished — status={} read={} written={} skipped={} duration={}ms",
                    jobName, execution.getStatus(), read, written, skipped, duration);

            return new BatchSummary(jobName, execution.getStatus().name(), read, written, skipped, duration);

        } catch (JobInstanceAlreadyCompleteException e) {
            log.warn("Job {} already completed, skipping.", jobName);
            return new BatchSummary(jobName, "SKIPPED", 0, 0, 0, 0);
        } catch (JobExecutionAlreadyRunningException | JobRestartException e) {
            log.error("Job {} launch error: {}", jobName, e.getMessage());
            return new BatchSummary(jobName, "ERROR", 0, 0, 0, 0);
        } catch (Exception e) {
            log.error("Job {} failed unexpectedly: {}", jobName, e.getMessage(), e);
            return new BatchSummary(jobName, "FAILED", 0, 0, 0, 0);
        }
    }

    public record BatchSummary(
            String jobName,
            String status,
            long recordsRead,
            long recordsWritten,
            long recordsSkipped,
            long durationMs
    ) {
        public double durationSec() { return durationMs / 1000.0; }
    }
}
