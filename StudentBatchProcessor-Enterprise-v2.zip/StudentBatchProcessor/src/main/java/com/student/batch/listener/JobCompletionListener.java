package com.student.batch.listener;

import com.student.batch.monitor.BatchMonitoringService;
import com.student.entity.BatchJobExecutionEntity;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;

/**
 * Observer Pattern: JobCompletionListener listens to batch job lifecycle events.
 *
 * WHY Observer Pattern:
 *  The batch job doesn't need to know about monitoring/reporting concerns.
 *  The listener is an "observer" of job lifecycle that reacts independently.
 *
 * Spring Batch Integration:
 *  - beforeJob()  → called when job starts
 *  - afterJob()   → called when job finishes (success or failure)
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class JobCompletionListener implements JobExecutionListener {

    private final BatchMonitoringService monitoringService;

    @Override
    public void beforeJob(JobExecution jobExecution) {
        String jobName = jobExecution.getJobInstance().getJobName();
        log.info("════════════════════════════════════════════");
        log.info("  JOB STARTED: {}", jobName);
        log.info("  Job ID: {}", jobExecution.getId());
        log.info("  Start Time: {}", jobExecution.getStartTime());
        log.info("════════════════════════════════════════════");

        monitoringService.recordJobStart(jobName, jobExecution.getId());
    }

    @Override
    public void afterJob(JobExecution jobExecution) {
        String jobName   = jobExecution.getJobInstance().getJobName();
        String status    = jobExecution.getStatus().name();
        LocalDateTime end = LocalDateTime.now();

        long readCount    = jobExecution.getStepExecutions().stream()
                .mapToLong(s -> s.getReadCount()).sum();
        long writeCount   = jobExecution.getStepExecutions().stream()
                .mapToLong(s -> s.getWriteCount()).sum();
        long skipCount    = jobExecution.getStepExecutions().stream()
                .mapToLong(s -> s.getProcessSkipCount() + s.getReadSkipCount() + s.getWriteSkipCount()).sum();

        long durationMs = 0;
        if (jobExecution.getStartTime() != null) {
            durationMs = java.time.Duration.between(
                    jobExecution.getStartTime(), end).toMillis();
        }

        log.info("════════════════════════════════════════════");
        log.info("  JOB FINISHED: {}", jobName);
        log.info("  Status      : {}", status);
        log.info("  Records Read: {}", readCount);
        log.info("  Records Written: {}", writeCount);
        log.info("  Records Skipped: {}", skipCount);
        log.info("  Duration    : {} ms", durationMs);
        log.info("════════════════════════════════════════════");

        monitoringService.recordJobEnd(jobName, jobExecution.getId(),
                status, readCount, writeCount, skipCount, durationMs,
                jobExecution.getAllFailureExceptions().isEmpty() ? null
                        : jobExecution.getAllFailureExceptions().get(0).getMessage());
    }
}
