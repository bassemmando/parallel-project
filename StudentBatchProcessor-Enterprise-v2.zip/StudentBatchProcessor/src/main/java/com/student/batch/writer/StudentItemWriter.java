package com.student.batch.writer;

import com.student.entity.StudentEntity;
import com.student.repository.StudentRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.item.Chunk;
import org.springframework.batch.item.ItemWriter;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * Spring Batch ItemWriter: Load (L) step of ETL.
 *
 * Responsibilities:
 *  - Persist batch of StudentEntity to H2/JPA database
 *  - Handle duplicate studentId gracefully (upsert logic)
 *  - Log chunk write statistics
 *
 * Performance: Uses saveAll() for batch insertion (single transaction per chunk).
 * Spring Batch calls write() once per chunk with all processed items.
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class StudentItemWriter implements ItemWriter<StudentEntity> {

    private final StudentRepository studentRepository;

    @Override
    public void write(Chunk<? extends StudentEntity> chunk) throws Exception {
        List<? extends StudentEntity> items = chunk.getItems();
        log.debug("Writing chunk of {} students to database", items.size());

        long startMs = System.currentTimeMillis();

        // Filter out duplicates already in DB (skip if exists)
        List<StudentEntity> toSave = new ArrayList<>();
        int skipped = 0;

        for (StudentEntity entity : items) {
            if (!studentRepository.existsByStudentId(entity.getStudentId())) {
                toSave.add(entity);
            } else {
                skipped++;
                log.debug("Skipping duplicate studentId: {}", entity.getStudentId());
            }
        }

        if (!toSave.isEmpty()) {
            studentRepository.saveAll(toSave);
        }

        long elapsedMs = System.currentTimeMillis() - startMs;
        log.info("Wrote {} students ({} skipped duplicates) in {}ms",
                toSave.size(), skipped, elapsedMs);
    }
}
