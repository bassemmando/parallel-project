package com.student.batch.processor;

/**
 * Strategy Pattern: GradeStrategy interface.
 *
 * WHY: Different grading systems (Egyptian, International, etc.) may
 * categorize grades differently. The Strategy pattern allows us to
 * swap grading logic at runtime without changing the processor code.
 *
 * Implementations:
 *  - EgyptianGradeStrategy  → Egyptian university scale
 *  - InternationalGradeStrategy → Letter-grade scale (A/B/C/D/F)
 */
public interface GradeStrategy {

    /**
     * Categorize a raw numeric grade into a descriptive label.
     *
     * @param grade numeric grade (0–100)
     * @return category string (e.g. "EXCELLENT", "PASS", "FAIL")
     */
    String categorize(double grade);

    /**
     * Determine the status of a student based on their grade.
     *
     * @param grade numeric grade
     * @return "PASSED", "FAILED", or "TOP"
     */
    String determineStatus(double grade);

    /**
     * The minimum passing grade for this strategy.
     */
    double getPassingGrade();
}
