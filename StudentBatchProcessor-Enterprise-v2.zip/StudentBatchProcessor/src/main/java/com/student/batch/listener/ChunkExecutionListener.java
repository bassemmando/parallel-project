package com.student.batch.listener;

import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.ChunkListener;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.stereotype.Component;

/**
 * Observer Pattern: ChunkExecutionListener monitors each chunk's processing.
 *
 * Logs timing and counts per chunk — useful for performance profiling.
 */
@Slf4j
@Component
public class ChunkExecutionListener implements ChunkListener {

    private long chunkStartTime;

    @Override
    public void beforeChunk(ChunkContext context) {
        chunkStartTime = System.currentTimeMillis();
        log.debug("Chunk started — Step: {}",
                context.getStepContext().getStepName());
    }

    @Override
    public void afterChunk(ChunkContext context) {
        long elapsed = System.currentTimeMillis() - chunkStartTime;
        int  written = context.getStepContext().getStepExecution().getWriteCount();
        int  read    = context.getStepContext().getStepExecution().getReadCount();
        log.info("✔ Chunk complete — read so far: {}, written so far: {}, chunk time: {}ms",
                read, written, elapsed);
    }

    @Override
    public void afterChunkError(ChunkContext context) {
        log.error("✘ Chunk error in step: {}",
                context.getStepContext().getStepName());
    }
}
