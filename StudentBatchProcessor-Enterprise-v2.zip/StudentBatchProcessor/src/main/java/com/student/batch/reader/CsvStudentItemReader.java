package com.student.batch.reader;

import com.student.dto.StudentDTO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.builder.FlatFileItemReaderBuilder;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.core.io.FileSystemResource;

/**
 * Spring Batch ItemReader: Extract (E) step of ETL — CSV Source.
 *
 * Uses Spring Batch's FlatFileItemReader which provides:
 *  - Efficient line-by-line reading with buffering
 *  - Automatic header skipping
 *  - Field mapping to DTO
 *  - Restart capability (tracks read position)
 *
 * Factory Method Pattern: static factory method creates configured reader.
 */
@Slf4j
public class CsvStudentItemReader extends FlatFileItemReader<StudentDTO> {

    /**
     * Factory Method Pattern: creates a fully configured CSV reader.
     * WHY: Centralises reader construction logic, avoids duplication.
     *
     * @param filePath path to the input CSV file
     * @return configured FlatFileItemReader
     */
    public static FlatFileItemReader<StudentDTO> create(String filePath) {
        log.info("Creating CSV ItemReader for file: {}", filePath);

        BeanWrapperFieldSetMapper<StudentDTO> fieldSetMapper = new BeanWrapperFieldSetMapper<>();
        fieldSetMapper.setTargetType(StudentDTO.class);

        return new FlatFileItemReaderBuilder<StudentDTO>()
                .name("csvStudentItemReader")
                .resource(new FileSystemResource(filePath))
                .linesToSkip(1)               // skip header row
                .delimited()
                .delimiter(",")
                .names("studentId", "name", "department", "subject", "grade", "semester")
                .fieldSetMapper(fieldSetMapper)
                .strict(false)                // don't fail on missing fields
                .build();
    }
}
