package com.student.batch.listener;

import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.stereotype.Component;

/**
 * Observer Pattern: StepExecutionListener logs step-level lifecycle events.
 */
@Slf4j
@Component
public class StepLoggingListener implements StepExecutionListener {

    @Override
    public void beforeStep(StepExecution stepExecution) {
        log.info("──── Step STARTED: {} ────", stepExecution.getStepName());
    }

    @Override
    public ExitStatus afterStep(StepExecution stepExecution) {
        log.info("──── Step FINISHED: {} ────", stepExecution.getStepName());
        log.info("  Read    : {}", stepExecution.getReadCount());
        log.info("  Written : {}", stepExecution.getWriteCount());
        log.info("  Skipped : {}", stepExecution.getProcessSkipCount()
                + stepExecution.getReadSkipCount() + stepExecution.getWriteSkipCount());
        log.info("  Commits : {}", stepExecution.getCommitCount());
        log.info("  Status  : {}", stepExecution.getExitStatus().getExitCode());
        return stepExecution.getExitStatus();
    }
}
