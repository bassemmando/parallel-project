package com.student.batch.config;

import com.student.batch.listener.ChunkExecutionListener;
import com.student.batch.listener.JobCompletionListener;
import com.student.batch.listener.StepLoggingListener;
import com.student.batch.processor.StudentItemProcessor;
import com.student.batch.reader.CsvStudentItemReader;
import com.student.batch.writer.StudentItemWriter;
import com.student.dto.StudentDTO;
import com.student.entity.StudentEntity;
import com.student.exception.InvalidStudentDataException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.task.TaskExecutor;
import org.springframework.transaction.PlatformTransactionManager;

/**
 * Spring Batch Configuration: CSV ETL Job
 *
 * ETL Flow:
 *   Extract  → FlatFileItemReader  (reads CSV line by line)
 *   Transform → StudentItemProcessor (validates + enriches with grade category)
 *   Load     → StudentItemWriter   (persists to H2 database)
 *
 * Features configured:
 *   - Chunk-oriented processing (chunkSize records per transaction)
 *   - Multi-threaded step via TaskExecutor (preserves existing threading)
 *   - Retry on transient errors (up to 3 attempts)
 *   - Skip on InvalidStudentDataException (bad records don't stop the job)
 *   - Full listener chain (Job + Step + Chunk observers)
 */
@Slf4j
@Configuration
@RequiredArgsConstructor
public class CsvBatchJobConfig {

    private final JobRepository             jobRepository;
    private final PlatformTransactionManager transactionManager;
    private final StudentItemProcessor      processor;
    private final StudentItemWriter         writer;
    private final JobCompletionListener     jobListener;
    private final StepLoggingListener       stepListener;
    private final ChunkExecutionListener    chunkListener;
    private final TaskExecutor              batchTaskExecutor;

    @Value("${app.batch.chunk-size:1000}")
    private int chunkSize;

    @Value("${app.batch.max-retry-attempts:3}")
    private int maxRetryAttempts;

    @Value("${app.batch.skip-limit:100}")
    private int skipLimit;

    @Value("${app.batch.retry-back-off-delay:1000}")
    private long retryBackOffDelay;

    @Value("${app.data.input-dir:data/input}")
    private String inputDir;

    // ────────────────────────────────────────────────────
    //  JOB DEFINITION
    // ────────────────────────────────────────────────────

    /**
     * CSV ETL Job: contains one step (csvProcessingStep).
     * JobCompletionListener observes start/end events.
     */
    @Bean("csvStudentJob")
    public Job csvStudentJob() {
        return new JobBuilder("csvStudentJob", jobRepository)
                .listener(jobListener)
                .start(csvProcessingStep())
                .build();
    }

    // ────────────────────────────────────────────────────
    //  STEP DEFINITION
    // ────────────────────────────────────────────────────

    /**
     * Step: chunk-oriented with multi-threading.
     *
     * <T=StudentDTO, R=StudentEntity>:
     *   reader    → produces StudentDTO
     *   processor → transforms to StudentEntity
     *   writer    → persists StudentEntity
     *
     * Retry:    on RuntimeException, up to maxRetryAttempts
     * Skip:     on InvalidStudentDataException, up to skipLimit records
     * Threading: batchTaskExecutor provides parallel chunk processing
     */
    @Bean
    public Step csvProcessingStep() {
        FlatFileItemReader<StudentDTO> csvReader =
                CsvStudentItemReader.create(inputDir + "/students.csv");

        return new StepBuilder("csvProcessingStep", jobRepository)
                .<StudentDTO, StudentEntity>chunk(chunkSize, transactionManager)
                .reader(csvReader)
                .processor(processor)
                .writer(writer)
                // ── Retry mechanism ──
                .faultTolerant()
                .retryLimit(maxRetryAttempts)
                .retry(RuntimeException.class)
                // ── Skip invalid records ──
                .skipLimit(skipLimit)
                .skip(InvalidStudentDataException.class)
                // ── Listeners (Observer pattern) ──
                .listener(stepListener)
                .listener(chunkListener)
                // ── Multi-threading (preserved from original) ──
                .taskExecutor(batchTaskExecutor)
                .build();
    }
}
