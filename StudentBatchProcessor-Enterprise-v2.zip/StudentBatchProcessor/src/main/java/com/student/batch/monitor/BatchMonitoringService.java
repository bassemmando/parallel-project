package com.student.batch.monitor;

import com.student.entity.BatchJobExecutionEntity;
import com.student.repository.BatchJobExecutionRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Batch Monitoring Service.
 *
 * Tracks job execution metadata in the database.
 * Provides a REST-queryable view of batch job health.
 *
 * Design: Singleton bean managed by Spring (Singleton Pattern).
 * Uses a ConcurrentHashMap to correlate Spring Batch jobId → our entity id
 * since Spring Batch's own tables are not easily queried at runtime here.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class BatchMonitoringService {

    private final BatchJobExecutionRepository executionRepository;

    // jobName+executionId → our entity id (in-memory correlation map)
    private final Map<String, Long> correlationMap = new ConcurrentHashMap<>();

    @Transactional
    public void recordJobStart(String jobName, Long springBatchId) {
        BatchJobExecutionEntity record = BatchJobExecutionEntity.builder()
                .jobName(jobName)
                .status("RUNNING")
                .startTime(LocalDateTime.now())
                .recordsRead(0L)
                .recordsWritten(0L)
                .recordsSkipped(0L)
                .build();

        BatchJobExecutionEntity saved = executionRepository.save(record);
        correlationMap.put(correlationKey(jobName, springBatchId), saved.getId());
        log.info("Monitoring: recorded job start — {} (id={})", jobName, saved.getId());
    }

    @Transactional
    public void recordJobEnd(String jobName, Long springBatchId,
                             String status, long read, long written,
                             long skipped, long durationMs, String errorMsg) {
        String key     = correlationKey(jobName, springBatchId);
        Long   ownId   = correlationMap.get(key);

        if (ownId != null) {
            executionRepository.findById(ownId).ifPresent(record -> {
                record.setStatus(status);
                record.setEndTime(LocalDateTime.now());
                record.setRecordsRead(read);
                record.setRecordsWritten(written);
                record.setRecordsSkipped(skipped);
                record.setDurationMs(durationMs);
                record.setErrorMessage(errorMsg);
                executionRepository.save(record);
                log.info("Monitoring: recorded job end — {} status={} read={} written={} skipped={}",
                        jobName, status, read, written, skipped);
            });
            correlationMap.remove(key);
        }
    }

    public List<BatchJobExecutionEntity> getAllExecutions() {
        return executionRepository.findAllByOrderByStartTimeDesc();
    }

    public List<BatchJobExecutionEntity> getByStatus(String status) {
        return executionRepository.findByStatus(status);
    }

    private String correlationKey(String jobName, Long id) {
        return jobName + "_" + id;
    }
}
