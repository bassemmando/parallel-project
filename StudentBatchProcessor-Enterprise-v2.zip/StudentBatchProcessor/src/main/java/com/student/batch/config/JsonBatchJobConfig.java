package com.student.batch.config;

import com.student.batch.listener.ChunkExecutionListener;
import com.student.batch.listener.JobCompletionListener;
import com.student.batch.listener.StepLoggingListener;
import com.student.batch.processor.StudentItemProcessor;
import com.student.batch.reader.JsonStudentItemReader;
import com.student.batch.writer.StudentItemWriter;
import com.student.dto.StudentDTO;
import com.student.entity.StudentEntity;
import com.student.exception.InvalidStudentDataException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.PlatformTransactionManager;

/**
 * Spring Batch Configuration: JSON ETL Job
 *
 * ETL Flow:
 *   Extract  → JsonStudentItemReader  (reads JSON array)
 *   Transform → StudentItemProcessor  (same processor, reused)
 *   Load     → StudentItemWriter      (same writer, persists to DB)
 *
 * Note: JSON job runs AFTER CSV job in orchestration to avoid duplicate-id conflicts.
 * The writer handles duplicates gracefully (skip if studentId already exists).
 */
@Slf4j
@Configuration
@RequiredArgsConstructor
public class JsonBatchJobConfig {

    private final JobRepository             jobRepository;
    private final PlatformTransactionManager transactionManager;
    private final StudentItemProcessor      processor;
    private final StudentItemWriter         writer;
    private final JobCompletionListener     jobListener;
    private final StepLoggingListener       stepListener;
    private final ChunkExecutionListener    chunkListener;

    @Value("${app.batch.chunk-size:1000}")
    private int chunkSize;

    @Value("${app.batch.skip-limit:100}")
    private int skipLimit;

    @Value("${app.data.input-dir:data/input}")
    private String inputDir;

    @Bean("jsonStudentJob")
    public Job jsonStudentJob() {
        return new JobBuilder("jsonStudentJob", jobRepository)
                .listener(jobListener)
                .start(jsonProcessingStep())
                .build();
    }

    @Bean
    public Step jsonProcessingStep() {
        JsonStudentItemReader jsonReader =
                new JsonStudentItemReader(inputDir + "/students.json");

        return new StepBuilder("jsonProcessingStep", jobRepository)
                .<StudentDTO, StudentEntity>chunk(chunkSize, transactionManager)
                .reader(jsonReader)
                .processor(processor)
                .writer(writer)
                .faultTolerant()
                .skipLimit(skipLimit)
                .skip(InvalidStudentDataException.class)
                .listener(stepListener)
                .listener(chunkListener)
                .build();
    }
}
