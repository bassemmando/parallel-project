package com.student.batch.reader;

import com.student.dto.StudentDTO;
import com.student.entity.StudentEntity;
import com.student.repository.StudentRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.item.ItemReader;
import org.springframework.stereotype.Component;

import java.util.Iterator;
import java.util.List;

/**
 * Spring Batch ItemReader: Extract from Database.
 *
 * Used in the reporting/re-processing batch job.
 * Reads StudentEntity from JPA and converts to StudentDTO for re-use.
 *
 * This demonstrates reading from DB as a source — useful for:
 *  - Re-processing after data corrections
 *  - Cross-validation between CSV/JSON and DB
 *  - Report generation jobs
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class DatabaseStudentItemReader implements ItemReader<StudentDTO> {

    private final StudentRepository studentRepository;
    private Iterator<StudentEntity> iterator;
    private boolean initialized = false;

    @Override
    public synchronized StudentDTO read() {
        if (!initialized) {
            initialize();
        }

        if (iterator != null && iterator.hasNext()) {
            StudentEntity entity = iterator.next();
            return mapToDTO(entity);
        }

        return null; // end of data
    }

    public void reset() {
        initialized = false;
        iterator    = null;
    }

    private void initialize() {
        log.info("Initializing Database ItemReader...");
        List<StudentEntity> students = studentRepository.findAll();
        log.info("Loaded {} students from database", students.size());
        iterator    = students.iterator();
        initialized = true;
    }

    private StudentDTO mapToDTO(StudentEntity entity) {
        return StudentDTO.builder()
                .studentId(entity.getStudentId())
                .name(entity.getName())
                .department(entity.getDepartment())
                .subject(entity.getSubject())
                .grade(entity.getGrade())
                .semester(entity.getSemester())
                .build();
    }
}
