package com.student.batch.config;

import com.student.batch.listener.JobCompletionListener;
import com.student.batch.listener.StepLoggingListener;
import com.student.batch.reader.DatabaseStudentItemReader;
import com.student.batch.writer.CsvReportItemWriter;
import com.student.dto.StudentDTO;
import com.student.entity.StudentEntity;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.PlatformTransactionManager;
import java.io.File;


/**
 * Spring Batch Configuration: Reporting Job
 *
 * Runs AFTER CSV+JSON jobs have loaded data into the DB.
 *
 * Steps:
 *   1. setupReportDirStep  → Tasklet: creates output directory
 *   2. generateReportStep  → Chunk: DB → CSV report file
 *
 * Demonstrates:
 *   - Tasklet step (non-chunk, one-shot operation)
 *   - Sequential steps within a single Job
 *   - DB as ETL source (reading back what was loaded)
 */
@Slf4j
@Configuration
@RequiredArgsConstructor
public class ReportBatchJobConfig {

    private final JobRepository              jobRepository;
    private final PlatformTransactionManager transactionManager;
    private final DatabaseStudentItemReader  dbReader;
    private final JobCompletionListener      jobListener;
    private final StepLoggingListener        stepListener;

    @Value("${app.batch.chunk-size:1000}")
    private int chunkSize;

    @Value("${app.data.output-dir:data/output}")
    private String outputDir;

    // ── Processor: DB entity → same entity (pass-through for report) ──
    // We use a simple lambda processor here — no transformation needed
    // since the entity is already enriched from earlier jobs.

    @Bean("reportGenerationJob")
    public Job reportGenerationJob() {
        return new JobBuilder("reportGenerationJob", jobRepository)
                .listener(jobListener)
                .start(setupReportDirStep())
                .next(generateAllStudentsReportStep())
                .build();
    }

    /**
     * Tasklet Step: create the output directory.
     * WHY Tasklet: one-shot setup tasks don't need chunk processing.
     */
    @Bean
    public Step setupReportDirStep() {
        Tasklet setupTasklet = (contribution, chunkCtx) -> {
            File dir = new File(outputDir);
            if (dir.mkdirs()) {
                log.info("Created output directory: {}", outputDir);
            }
            log.info("Output directory ready: {}", dir.getAbsolutePath());
            return RepeatStatus.FINISHED;
        };

        return new StepBuilder("setupReportDirStep", jobRepository)
                .tasklet(setupTasklet, transactionManager)
                .listener(stepListener)
                .build();
    }

    /**
     * Chunk Step: read all students from DB → write to full report CSV.
     */
    @Bean
    public Step generateAllStudentsReportStep() {
        CsvReportItemWriter reportWriter =
                new CsvReportItemWriter(outputDir + "/all_students_report.csv");

        return new StepBuilder("generateAllStudentsReportStep", jobRepository)
                .<StudentDTO, StudentEntity>chunk(chunkSize, transactionManager)
                .reader(dbReader)
                .processor(item -> {
                    // Pass-through: DTO from DB reader → find entity to write
                    // For report job, we re-map DTO → entity inline
                    return StudentEntity.builder()
                            .studentId(item.getStudentId())
                            .name(item.getName())
                            .department(item.getDepartment())
                            .subject(item.getSubject())
                            .grade(item.getGrade())
                            .semester(item.getSemester())
                            .build();
                })
                .writer(reportWriter)
                .faultTolerant()
                .skip(Exception.class)
                .skipLimit(50)
                .listener(stepListener)
                .build();
    }
}
