package com.student.batch.processor;

import org.springframework.stereotype.Component;

/**
 * Strategy Pattern Implementation: Egyptian University Grading Scale
 *
 * Egyptian Scale:
 *  - 85–100 : EXCELLENT
 *  - 75–84  : VERY_GOOD
 *  - 65–74  : GOOD
 *  - 50–64  : AVERAGE
 *  - 0–49   : FAIL
 */
@Component("egyptianGradeStrategy")
public class EgyptianGradeStrategy implements GradeStrategy {

    private static final double PASSING_GRADE   = 50.0;
    private static final double TOP_GRADE        = 85.0;

    @Override
    public String categorize(double grade) {
        if (grade >= 85.0) return "EXCELLENT";
        if (grade >= 75.0) return "VERY_GOOD";
        if (grade >= 65.0) return "GOOD";
        if (grade >= 50.0) return "AVERAGE";
        return "FAIL";
    }

    @Override
    public String determineStatus(double grade) {
        if (grade >= TOP_GRADE)     return "TOP";
        if (grade >= PASSING_GRADE) return "PASSED";
        return "FAILED";
    }

    @Override
    public double getPassingGrade() {
        return PASSING_GRADE;
    }
}
