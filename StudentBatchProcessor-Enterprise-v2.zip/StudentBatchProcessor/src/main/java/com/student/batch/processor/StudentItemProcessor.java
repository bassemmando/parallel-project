package com.student.batch.processor;

import com.student.dto.StudentDTO;
import com.student.entity.StudentEntity;
import com.student.exception.InvalidStudentDataException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;

/**
 * Spring Batch ItemProcessor: Transform (T) step of ETL.
 *
 * Responsibilities:
 *  - Validate incoming StudentDTO
 *  - Transform DTO → Entity (mapping layer)
 *  - Apply GradeStrategy to enrich with status & category
 *  - Throw InvalidStudentDataException for skippable errors
 *
 * Design Patterns used:
 *  - Strategy Pattern: delegates grading logic to GradeStrategy
 *  - Dependency Injection: strategy injected via Spring
 *
 * Spring Batch Integration:
 *  - Returning null → item is filtered (not written)
 *  - Throwing exception → triggers retry/skip mechanism
 */
@Slf4j
@Component
public class StudentItemProcessor implements ItemProcessor<StudentDTO, StudentEntity> {

    private final GradeStrategy gradeStrategy;

    /**
     * Strategy Pattern: We inject the Egyptian strategy by default.
     * Can be changed at runtime by providing a different qualifier.
     */
    public StudentItemProcessor(
            @Qualifier("egyptianGradeStrategy") GradeStrategy gradeStrategy) {
        this.gradeStrategy = gradeStrategy;
    }

    @Override
    public StudentEntity process(StudentDTO dto) throws Exception {
        log.debug("Processing student: ID={}, Name={}", dto.getStudentId(), dto.getName());

        // ── Validation (Transform step guard) ──────────────
        validateStudent(dto);

        // ── Transform: DTO → Entity ────────────────────────
        String status   = gradeStrategy.determineStatus(dto.getGrade());
        String category = gradeStrategy.categorize(dto.getGrade());

        StudentEntity entity = StudentEntity.builder()
                .studentId(dto.getStudentId())
                .name(normalizeName(dto.getName()))
                .department(dto.getDepartment().toUpperCase().trim())
                .subject(dto.getSubject().trim())
                .grade(dto.getGrade())
                .semester(dto.getSemester() != null ? dto.getSemester().trim() : "UNKNOWN")
                .status(status)
                .gradeCategory(category)
                .processedAt(LocalDateTime.now())
                .build();

        log.debug("Transformed student: ID={}, status={}, category={}",
                entity.getStudentId(), entity.getStatus(), entity.getGradeCategory());

        return entity;
    }

    // ─── Private validation logic ──────────────────────────

    private void validateStudent(StudentDTO dto) {
        if (dto.getStudentId() == null || dto.getStudentId() <= 0) {
            throw new InvalidStudentDataException(
                "Invalid StudentID: " + dto.getStudentId());
        }
        if (dto.getName() == null || dto.getName().isBlank()) {
            throw new InvalidStudentDataException(
                "Blank name for StudentID: " + dto.getStudentId());
        }
        if (dto.getGrade() == null || dto.getGrade() < 0 || dto.getGrade() > 100) {
            throw new InvalidStudentDataException(
                "Invalid grade " + dto.getGrade() + " for StudentID: " + dto.getStudentId());
        }
        if (dto.getDepartment() == null || dto.getDepartment().isBlank()) {
            throw new InvalidStudentDataException(
                "Missing department for StudentID: " + dto.getStudentId());
        }
    }

    private String normalizeName(String name) {
        if (name == null) return "";
        return name.trim()
                   .replaceAll("\\s+", " ")
                   .chars()
                   .collect(StringBuilder::new, (sb, c) -> {
                       if (sb.isEmpty() || sb.charAt(sb.length() - 1) == ' ') {
                           sb.append(Character.toUpperCase(c));
                       } else {
                           sb.append(Character.toLowerCase(c));
                       }
                   }, StringBuilder::append)
                   .toString();
    }
}
