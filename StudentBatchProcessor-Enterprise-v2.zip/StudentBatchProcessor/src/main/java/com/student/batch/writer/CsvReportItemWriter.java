package com.student.batch.writer;

import com.student.entity.StudentEntity;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;
import org.springframework.batch.item.Chunk;
import org.springframework.batch.item.ItemWriter;

import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

/**
 * ItemWriter: writes processed student records to CSV report files.
 * Used in the reporting batch job to generate output files.
 */
@Slf4j
public class CsvReportItemWriter implements ItemWriter<StudentEntity> {

    private final String outputPath;
    private CSVPrinter printer;
    private FileWriter fileWriter;
    private boolean headerWritten = false;

    public CsvReportItemWriter(String outputPath) {
        this.outputPath = outputPath;
    }

    public void open() throws IOException {
        fileWriter = new FileWriter(outputPath, true);
        if (!headerWritten) {
            printer = new CSVPrinter(fileWriter,
                    CSVFormat.DEFAULT.builder()
                            .setHeader("StudentID","Name","Department","Subject","Grade","Semester","Status","Category","ProcessedAt")
                            .build());
            headerWritten = true;
        } else {
            printer = new CSVPrinter(fileWriter, CSVFormat.DEFAULT);
        }
        log.info("Opened CSV writer: {}", outputPath);
    }

    @Override
    public void write(Chunk<? extends StudentEntity> chunk) throws Exception {
        if (printer == null) open();

        for (StudentEntity e : chunk.getItems()) {
            printer.printRecord(
                    e.getStudentId(), e.getName(), e.getDepartment(),
                    e.getSubject(), e.getGrade(), e.getSemester(),
                    e.getStatus(), e.getGradeCategory(),
                    e.getProcessedAt()
            );
        }
        printer.flush();
        log.debug("Wrote {} records to {}", chunk.size(), outputPath);
    }

    public void close() throws IOException {
        if (printer != null) printer.close(true);
        log.info("Closed CSV writer: {}", outputPath);
    }
}
