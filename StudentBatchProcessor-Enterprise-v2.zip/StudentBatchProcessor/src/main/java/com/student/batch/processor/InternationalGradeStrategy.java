package com.student.batch.processor;

import org.springframework.stereotype.Component;

/**
 * Strategy Pattern Implementation: International Letter-Grade Scale
 *
 * International Scale:
 *  - 90–100 : A (EXCELLENT)
 *  - 80–89  : B (GOOD)
 *  - 70–79  : C (ABOVE_AVERAGE)
 *  - 60–69  : D (AVERAGE)
 *  - 0–59   : F (FAIL)
 */
@Component("internationalGradeStrategy")
public class InternationalGradeStrategy implements GradeStrategy {

    private static final double PASSING_GRADE = 60.0;
    private static final double TOP_GRADE      = 90.0;

    @Override
    public String categorize(double grade) {
        if (grade >= 90.0) return "EXCELLENT";
        if (grade >= 80.0) return "GOOD";
        if (grade >= 70.0) return "ABOVE_AVERAGE";
        if (grade >= 60.0) return "AVERAGE";
        return "FAIL";
    }

    @Override
    public String determineStatus(double grade) {
        if (grade >= TOP_GRADE)     return "TOP";
        if (grade >= PASSING_GRADE) return "PASSED";
        return "FAILED";
    }

    @Override
    public double getPassingGrade() {
        return PASSING_GRADE;
    }
}
