package com.student;

import com.student.generator.DataGenerator;
import com.student.repository.StudentRepository;
import com.student.service.BatchOrchestrationService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Integration test: runs the full batch pipeline against an in-memory H2 DB.
 */
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.NONE)
@ActiveProfiles("dev")
class BatchIntegrationTest {

    @Autowired
    private DataGenerator dataGenerator;

    @Autowired
    private BatchOrchestrationService orchestrationService;

    @Autowired
    private StudentRepository studentRepository;

    @BeforeEach
    void setup() throws Exception {
        studentRepository.deleteAll();
        dataGenerator.generateAll();
    }

    @Test
    @DisplayName("Full pipeline: generate → batch → DB has records")
    void fullPipeline_dbPopulated() {
        orchestrationService.runAllJobs();
        long count = studentRepository.count();
        assertThat(count).isGreaterThan(0);
    }

    @Test
    @DisplayName("Students have status assigned after processing")
    void allStudents_haveStatus() {
        orchestrationService.runAllJobs();
        long withStatus = studentRepository.findAll().stream()
                .filter(s -> s.getStatus() != null)
                .count();
        assertThat(withStatus).isEqualTo(studentRepository.count());
    }

    @Test
    @DisplayName("Pass rate within expected range 40%-95%")
    void passRate_withinExpectedRange() {
        orchestrationService.runAllJobs();
        long total  = studentRepository.count();
        long passed = studentRepository.countPassed();
        if (total > 0) {
            double rate = (passed * 100.0 / total);
            assertThat(rate).isBetween(40.0, 95.0);
        }
    }
}
