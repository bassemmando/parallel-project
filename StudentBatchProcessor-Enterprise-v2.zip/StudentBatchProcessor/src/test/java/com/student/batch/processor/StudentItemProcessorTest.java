package com.student.batch.processor;

import com.student.dto.StudentDTO;
import com.student.entity.StudentEntity;
import com.student.exception.InvalidStudentDataException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.*;

/**
 * Unit test for StudentItemProcessor.
 * Tests validation, transformation, and Strategy integration.
 */
class StudentItemProcessorTest {

    private StudentItemProcessor processor;

    @BeforeEach
    void setUp() {
        processor = new StudentItemProcessor(new EgyptianGradeStrategy());
    }

    @Test
    @DisplayName("Valid student with high grade → TOP status, EXCELLENT category")
    void process_validTopStudent() throws Exception {
        StudentDTO dto = StudentDTO.builder()
                .studentId(1).name("Ahmed Ali")
                .department("CS").subject("Math")
                .grade(90.0).semester("Fall2024")
                .build();

        StudentEntity result = processor.process(dto);

        assertThat(result).isNotNull();
        assertThat(result.getStatus()).isEqualTo("TOP");
        assertThat(result.getGradeCategory()).isEqualTo("EXCELLENT");
        assertThat(result.getName()).isEqualTo("Ahmed Ali");
        assertThat(result.getDepartment()).isEqualTo("CS");
    }

    @Test
    @DisplayName("Passing student (65) → PASSED status, GOOD category")
    void process_passingStudent() throws Exception {
        StudentDTO dto = StudentDTO.builder()
                .studentId(2).name("Sara Mohamed")
                .department("IT").subject("OOP")
                .grade(65.0).semester("Spring2024")
                .build();

        StudentEntity result = processor.process(dto);

        assertThat(result.getStatus()).isEqualTo("PASSED");
        assertThat(result.getGradeCategory()).isEqualTo("GOOD");
    }

    @Test
    @DisplayName("Failing student (40) → FAILED status, FAIL category")
    void process_failingStudent() throws Exception {
        StudentDTO dto = StudentDTO.builder()
                .studentId(3).name("Omar Hassan")
                .department("AI").subject("Networks")
                .grade(40.0).semester("Fall2024")
                .build();

        StudentEntity result = processor.process(dto);

        assertThat(result.getStatus()).isEqualTo("FAILED");
        assertThat(result.getGradeCategory()).isEqualTo("FAIL");
    }

    @Test
    @DisplayName("Blank name → throws InvalidStudentDataException")
    void process_blankName_throws() {
        StudentDTO dto = StudentDTO.builder()
                .studentId(4).name("")
                .department("CS").subject("Math")
                .grade(75.0).semester("Fall2024")
                .build();

        assertThatThrownBy(() -> processor.process(dto))
                .isInstanceOf(InvalidStudentDataException.class)
                .hasMessageContaining("Blank name");
    }

    @Test
    @DisplayName("Grade > 100 → throws InvalidStudentDataException")
    void process_invalidGrade_throws() {
        StudentDTO dto = StudentDTO.builder()
                .studentId(5).name("Test Student")
                .department("CS").subject("Math")
                .grade(150.0).semester("Fall2024")
                .build();

        assertThatThrownBy(() -> processor.process(dto))
                .isInstanceOf(InvalidStudentDataException.class)
                .hasMessageContaining("Invalid grade");
    }

    @Test
    @DisplayName("Null studentId → throws InvalidStudentDataException")
    void process_nullId_throws() {
        StudentDTO dto = StudentDTO.builder()
                .studentId(null).name("Test Student")
                .department("CS").subject("Math")
                .grade(75.0).semester("Fall2024")
                .build();

        assertThatThrownBy(() -> processor.process(dto))
                .isInstanceOf(InvalidStudentDataException.class);
    }

    @Test
    @DisplayName("Name normalization: extra spaces trimmed")
    void process_nameNormalized() throws Exception {
        StudentDTO dto = StudentDTO.builder()
                .studentId(6).name("  ahmed   ali  ")
                .department("CS").subject("Math")
                .grade(70.0).semester("Fall2024")
                .build();

        StudentEntity result = processor.process(dto);

        assertThat(result.getName()).isEqualTo("Ahmed Ali");
    }
}
