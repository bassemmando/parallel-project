# 🎓 Student Batch Processor — Enterprise Edition v2.0

> **Spring Batch + Clean Architecture + Design Patterns**
> ETL Pipeline: CSV → JSON → Database → Reports

---

## 📋 Table of Contents
1. [Project Overview](#-project-overview)
2. [Tech Stack](#-tech-stack)
3. [Quick Start](#-quick-start)
4. [Architecture](#-architecture)
5. [Spring Batch — ETL Flow](#-spring-batch--etl-flow)
6. [Design Patterns Used](#-design-patterns-used)
7. [REST API — Batch Monitoring](#-rest-api--batch-monitoring)
8. [Project Structure](#-project-structure)
9. [Configuration Profiles](#-configuration-profiles)

---

## 📌 Project Overview

The **Student Batch Processor** is an enterprise-grade ETL system that:

1. **Generates** 100,000 student records as CSV + 10,000 as JSON
2. **Processes** them via Spring Batch (Extract → Transform → Load)
3. **Persists** enriched records into an H2 database
4. **Reports** statistics via console + CSV files + REST API

It demonstrates real-world usage of:
- **Spring Batch** with Chunk Processing, Retry, Skip, Multi-Threading
- **Clean Layered Architecture** (Controller → Service → Repository → Entity)
- **Design Patterns**: Strategy, Factory Method, Observer, Template Method, Builder, Singleton, DI

---

## 🛠 Tech Stack

| Technology           | Version | Purpose                        |
|----------------------|---------|--------------------------------|
| Spring Boot          | 3.2.3   | Application framework          |
| Spring Batch         | 5.x     | Batch job orchestration        |
| Spring Data JPA      | 3.2.x   | Database access layer          |
| H2 Database          | 2.x     | In-memory persistence          |
| Spring Web           | 3.2.x   | REST API for monitoring        |
| Lombok               | 1.18.x  | Boilerplate reduction          |
| Apache Commons CSV   | 1.10.0  | CSV reading/writing            |
| Jackson              | 2.x     | JSON parsing                   |
| Java                 | 17      | Language version               |

---

## 🚀 Quick Start

### Prerequisites
- Java 17+
- Maven 3.8+

### Run
```bash
# Clone / unzip project
cd StudentBatchProcessor

# Build
mvn clean package -DskipTests

# Run (dev profile — 10K records, debug logging)
java -jar target/StudentBatchProcessor-2.0.0.jar --spring.profiles.active=dev

# Or run directly
mvn spring-boot:run

# Production run (100K records)
mvn spring-boot:run -Dspring-boot.run.profiles=prod
```

### Outputs
| Location | Description |
|---|---|
| `data/input/students.csv` | Generated CSV input (100K rows) |
| `data/input/students.json` | Generated JSON input (10K records) |
| `data/output/all_students_report.csv` | Full processed report |
| `logs/student-batch.log` | Application log |
| `http://localhost:8080/api/batch/stats` | Live stats REST API |
| `http://localhost:8080/h2-console` | H2 DB Browser (dev) |

---

## 🏛 Architecture

```
┌─────────────────────────────────────────────────────────┐
│                   Presentation Layer                     │
│  BatchMonitoringController  │  StudentController         │
├─────────────────────────────────────────────────────────┤
│                    Service Layer                         │
│  BatchOrchestrationService  │  StudentService            │
├─────────────────────────────────────────────────────────┤
│                   Batch Layer                            │
│  Reader (CSV/JSON/DB) → Processor → Writer (DB/CSV)      │
│  Jobs: csvStudentJob | jsonStudentJob | reportJob        │
├─────────────────────────────────────────────────────────┤
│                  Repository Layer                        │
│  StudentRepository  │  BatchJobExecutionRepository       │
├─────────────────────────────────────────────────────────┤
│                    Entity Layer                          │
│  StudentEntity  │  BatchJobExecutionEntity               │
├─────────────────────────────────────────────────────────┤
│              Infrastructure / Config                     │
│  H2 DB  │  Spring Batch JobRepository  │  TaskExecutor  │
└─────────────────────────────────────────────────────────┘
```

The architecture is **Layered Clean Architecture**:
- Each layer only depends on the layer directly below it
- DTOs cross layer boundaries; Entities stay in repository/batch layers
- No circular dependencies

---

## ⚙️ Spring Batch — ETL Flow

### Three Production Jobs

```
╔══════════════════════════╗     ╔══════════════════════════╗     ╔══════════════════════════╗
║     csvStudentJob         ║     ║    jsonStudentJob          ║     ║  reportGenerationJob      ║
║  ─────────────────────   ║     ║  ─────────────────────    ║     ║  ─────────────────────   ║
║  Extract: CSV file        ║     ║  Extract: JSON file        ║     ║  Step 1: Tasklet          ║
║    ↓ FlatFileItemReader   ║ ──► ║    ↓ JsonStudentItemReader ║ ──► ║    (create output dir)   ║
║  Transform: Processor     ║     ║  Transform: same Processor ║     ║  Step 2: Chunk            ║
║    ↓ StudentItemProcessor ║     ║    ↓ StudentItemProcessor  ║     ║    DB Reader → CSV Writer ║
║  Load: DB Writer          ║     ║  Load: DB Writer           ║     ║                           ║
║    ↓ StudentItemWriter    ║     ║    ↓ StudentItemWriter     ║     ║                           ║
╚══════════════════════════╝     ╚══════════════════════════╝     ╚══════════════════════════╝
```

### Chunk Processing

```
CSV File (100K rows)
        │
        ▼
┌───────────────────────────────────────────────────┐
│  FlatFileItemReader  ─ reads chunkSize (1000) rows │
│            │                                       │
│            ▼                                       │
│  StudentItemProcessor ─ validates + enriches       │
│    ├── Grade categorization (Strategy Pattern)     │
│    ├── Invalid records → InvalidStudentDataException│
│    │         └── SKIPPED (skip-limit: 100)         │
│    └── DTO → Entity transformation                │
│            │                                       │
│            ▼                                       │
│  StudentItemWriter ─ saveAll() to DB               │
│    └── Duplicate studentId → skipped gracefully   │
└───────────────────────────────────────────────────┘
        │
  (repeat for next chunk until EOF)
        │
        ▼
  JobCompletionListener.afterJob() fires
```

### Retry & Skip Configuration
```yaml
faultTolerant()
  .retryLimit(3)                        # retry up to 3x on RuntimeException
  .retry(RuntimeException.class)
  .skipLimit(100)                       # allow up to 100 bad records
  .skip(InvalidStudentDataException.class)
```

### Multi-Threading
```java
// Preserved from original project, wired into Spring Batch:
.taskExecutor(batchTaskExecutor)  // ThreadPoolTaskExecutor, 4 threads
```

Each chunk is processed by a thread from the pool — true parallel chunk processing.

---

## 🎨 Design Patterns Used

### 1. Strategy Pattern — Grading Scale
**File**: `GradeStrategy` interface + `EgyptianGradeStrategy` + `InternationalGradeStrategy`

**Why**: Different institutions use different grading scales. The processor delegates
categorization to a swappable strategy without changing its own code.

```java
// Swap strategy at runtime by changing @Qualifier:
@Qualifier("egyptianGradeStrategy")     // 50+ passes
@Qualifier("internationalGradeStrategy") // 60+ passes
```

### 2. Observer Pattern — Job & Chunk Listeners
**Files**: `JobCompletionListener`, `ChunkExecutionListener`, `StepLoggingListener`

**Why**: Batch jobs shouldn't know about monitoring/logging concerns.
Listeners observe lifecycle events independently.

```java
// Job fires events, listener reacts:
jobListener.beforeJob(execution)  // records start in DB
jobListener.afterJob(execution)   // records metrics in DB
```

### 3. Factory Method Pattern — Reader Creation
**File**: `CsvStudentItemReader.create(filePath)`

**Why**: Centralizes the complex FlatFileItemReader construction. Callers
don't need to know the builder configuration details.

```java
FlatFileItemReader<StudentDTO> reader = CsvStudentItemReader.create(path);
```

### 4. Builder Pattern — DTOs and Entities
**Files**: `StudentDTO`, `StudentEntity`, `StudentStatsDTO`, `BatchSummary`

**Why**: Complex objects with many optional fields. Lombok `@Builder` keeps
construction readable and avoids telescoping constructors.

### 5. Template Method Pattern — Statistics Building
**File**: `StudentService.buildStats()`

**Why**: `buildStats()` defines the skeleton algorithm (total → passed → failed →
departments → categories → assemble DTO). Sub-methods fill specific steps.

### 6. Singleton Pattern — Spring Beans
**All `@Service`, `@Component`, `@Repository` classes**

**Why**: Spring manages all beans as singletons by default. Monitoring service
uses a `ConcurrentHashMap` for thread-safe state — correct singleton behavior.

### 7. Dependency Injection — Throughout
**All constructors with `@RequiredArgsConstructor`**

**Why**: SOLID's Dependency Inversion Principle. High-level modules depend on
abstractions (interfaces like `GradeStrategy`, `ItemReader`, `ItemWriter`).

---

## 🌐 REST API — Batch Monitoring

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/batch/jobs` | All job executions |
| GET | `/api/batch/jobs/status/{status}` | Filter: RUNNING/COMPLETED/FAILED |
| GET | `/api/batch/stats` | Student statistics from DB |
| POST | `/api/batch/run` | Trigger manual re-run |
| GET | `/api/batch/health` | Health check |
| GET | `/api/students/top` | Top students (grade ≥ 85) |
| GET | `/api/students/failed` | Failed students (grade < 50) |
| GET | `/api/students/department/{dept}` | Students by department |
| GET | `/h2-console` | H2 database browser (dev only) |

---

## 📁 Project Structure

```
StudentBatchProcessor/
├── src/main/java/com/student/
│   ├── StudentBatchApplication.java     ← Spring Boot entry point
│   ├── batch/
│   │   ├── config/
│   │   │   ├── CsvBatchJobConfig.java   ← CSV ETL job definition
│   │   │   ├── JsonBatchJobConfig.java  ← JSON ETL job definition
│   │   │   └── ReportBatchJobConfig.java← Reporting job (Tasklet + Chunk)
│   │   ├── reader/
│   │   │   ├── CsvStudentItemReader.java← Factory Method: FlatFileItemReader
│   │   │   ├── JsonStudentItemReader.java← Custom JSON reader
│   │   │   └── DatabaseStudentItemReader.java ← JPA source for report job
│   │   ├── processor/
│   │   │   ├── GradeStrategy.java       ← Strategy interface
│   │   │   ├── EgyptianGradeStrategy.java
│   │   │   ├── InternationalGradeStrategy.java
│   │   │   └── StudentItemProcessor.java← ItemProcessor (Transform)
│   │   ├── writer/
│   │   │   ├── StudentItemWriter.java   ← JPA ItemWriter (Load)
│   │   │   └── CsvReportItemWriter.java ← CSV output writer
│   │   ├── listener/
│   │   │   ├── JobCompletionListener.java  ← Observer: job lifecycle
│   │   │   ├── ChunkExecutionListener.java ← Observer: chunk lifecycle
│   │   │   └── StepLoggingListener.java    ← Observer: step lifecycle
│   │   └── monitor/
│   │       └── BatchMonitoringService.java  ← Tracks job metrics in DB
│   ├── controller/
│   │   ├── BatchMonitoringController.java
│   │   └── StudentController.java
│   ├── service/
│   │   ├── BatchOrchestrationService.java
│   │   └── StudentService.java
│   ├── repository/
│   │   ├── StudentRepository.java
│   │   └── BatchJobExecutionRepository.java
│   ├── entity/
│   │   ├── StudentEntity.java
│   │   └── BatchJobExecutionEntity.java
│   ├── dto/
│   │   ├── StudentDTO.java
│   │   ├── StudentStatsDTO.java
│   │   └── BatchJobStatusDTO.java
│   ├── config/
│   │   └── BatchAppConfig.java          ← TaskExecutor bean
│   ├── exception/
│   │   ├── GlobalExceptionHandler.java
│   │   ├── InvalidStudentDataException.java
│   │   └── BatchDataReadException.java
│   ├── generator/
│   │   └── DataGenerator.java           ← Generates CSV + JSON input
│   └── util/
│       └── ReportPrinter.java
└── src/main/resources/
    ├── application.yml
    ├── application-dev.yml
    └── application-prod.yml
```

---

## 🔧 Configuration Profiles

| Profile | Records | Chunk Size | Threads | Logging |
|---------|---------|------------|---------|---------|
| `dev`  | 10,000  | 500        | 4       | DEBUG   |
| `prod` | 100,000 | 2,000      | 8       | INFO    |

Switch profile:
```bash
# dev (default)
mvn spring-boot:run

# prod
mvn spring-boot:run -Dspring-boot.run.profiles=prod
```

---

## 🏗 SOLID Principles Applied

| Principle | How |
|---|---|
| **S**ingle Responsibility | Each class has one reason to change |
| **O**pen/Closed | `GradeStrategy` open for extension, closed for modification |
| **L**iskov Substitution | `EgyptianGradeStrategy` fully substitutes `InternationalGradeStrategy` |
| **I**nterface Segregation | `GradeStrategy` is focused; `ItemReader/Writer/Processor` are minimal |
| **D**ependency Inversion | All dependencies injected via constructor, depend on interfaces |
